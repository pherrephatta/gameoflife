#ifndef VIEW_H
#define VIEW_H

#include <cstdint>
#include "Window.hpp"
#include "Model.hpp"

class View {

public:
	View() = delete;
	View(uint16_t width, uint16_t height);
	~View() = default;

	Window& window();							// return window

	void mClear();								// Clear the screen
	void mRenderChecker();						// Draw pattern, for testing purposes
	void mRenderModel(Model& model); 			// Render the model
	const static size_t mNbColors = 8;

private:
	Window mWindow;

	constexpr static SDL_Color mPaletteLight[mNbColors] {
        { 0xFF, 0xFF, 0xFF, 0xFF }, 	// White 
        { 0xFF, 0x00, 0x00, 0xFF }, 	// Red
        { 0x00, 0xFF, 0x00, 0xFF }, 	// Green
        { 0x00, 0x00, 0xFF, 0xFF }, 	// Blue
        { 0xFF, 0xFF, 0x00, 0xFF }, 	// Yellow
		{ 0xFF, 0x80, 0x00, 0xFF }, 	// Orange
        { 0xFF, 0x00, 0xFF, 0xFF }, 	// Magenta
        { 0x00, 0xFF, 0xFF, 0xFF }, 	// Cyan
	};

	constexpr static SDL_Color mPaletteDark[mNbColors] {
        { 0x00, 0x00, 0x00, 0xFF }, 	// Black 
        { 0x79, 0x00, 0x00, 0xFF }, 	// Dark Red
        { 0x00, 0x79, 0x00, 0xFF }, 	// Dark Green
        { 0x00, 0x00, 0x79, 0xFF }, 	// Dark Blue
        { 0x79, 0x79, 0x00, 0xFF }, 	// Dark Yellow
		{ 0x79, 0x40, 0x00, 0xFF }, 	// Dark Orange
        { 0x79, 0x00, 0x79, 0xFF }, 	// Dark Magenta
        { 0x00, 0x79, 0x79, 0xFF }, 	// Dark Cyan
	};
};

#endif // VIEW_H
