#include "Controller.hpp"
#include <cstdio>
#include <cassert>

int main(int argc, char *argv[]) {

<<<<<<< HEAD
	uint16_t wdWidth = 1000;
	uint16_t wdHeight = 1000;
=======
	uint16_t wdWidth = 400;
	uint16_t wdHeight = 300;
>>>>>>> bd5a51ab2c132e6b321c3bf8583aa849a4011b29

	// Changing window size at execution
	switch(argc) {
		case 2: {
			assert(atoi(argv[1]) > 0);
			wdWidth = wdHeight = atoi(argv[1]);
			break;
		}
		case 3: {
			assert(atoi(argv[1]) > 0);
			assert(atoi(argv[2]) > 0);
			wdWidth = atoi(argv[1]);
			wdHeight = atoi(argv[2]);
			break;
		}
		default: {
			break;
		}
	}

	View view(wdWidth, wdHeight);
	Model model(view.window().logWidth(), view.window().logHeight());
	Controller controller(model, view);
	controller.start();

	return 0;
}
